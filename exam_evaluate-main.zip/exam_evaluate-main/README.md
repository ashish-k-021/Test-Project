# What is Exam Evaluator ?
	Exam Evaluator is useful to evaluate answer sheets in digital format. The teacher can mark the answer sheets
	by just filling the form which is presented next to the answer sheet. After the evaluation, the result is 
	compiled automatically and the teacher can view/ download compiled result of the class in excel format and 
	student can download the mark sheet in PDF format.

# Features
 ## For Students
	- UploadAnswersheet
	- Show Answersheet
	- Download Marksheet
	- Result Board

## For Teachers
	- Modify / Delete Classes
	- Export Result
	- Load Students
	- Examine sheets

# Technologies Used
	- HTML
	- SASS(CSS)
	- JavaScript
	- PHP
# Future Scope
	- Feature to annotate on answersheets.
	- Feature to generate query & view query status, if a student feels to request re-checking of the answer sheet.
	- Option to edit profile details of Student and Teacher.
	- Export to email option for Class result and Student Marksheets.
